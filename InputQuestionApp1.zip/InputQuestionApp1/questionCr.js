/*this js file (by itself), when run with node, produces 
a json file with the correct format, though currently obsolete*/

var fs = require("fs");
var question = "a question ? ";

var question = {question};

fs.writeFile("./questions.json", JSON.stringify(question, null, 4), (err) => {
    if (err) {
        console.error(err);
        return;
    };
    console.log("File has been created successfully ");
});